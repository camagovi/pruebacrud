//archivo principal
const express = require('express');
const path = require('path');
const morgan = require('morgan');
//base de datos
const mysql = require('mysql');
const myConnection = require('express-myconnection');

const app = express();

//settings
app.set('port', process.env.PORT || 3000); // Lea el puerto del sistema o el 3000
app.set('view engine', 'ejs'); //ya esta instalado ejs - motor de plantillas
app.set('views', path.join(__dirname, 'views')); //__dirmane contiene la ruta de la carpeta del archivo
                                                //que se ejecuta app, y join lo concatena, lo hace multiplataforma

// middlewares se ejecutan antes de las peticiones de los usuarios FUNCIONES
app.use(morgan('dev')); // muestra mensajes por consola, se pueden ver las peticiones que realicen
app.use(myConnection(mysql,{
    host: 'localhost',
    user: 'root',
    password: '8256',
    port: 3306,
    database: 'pruebacrud'
},'single'));// como se conecta al servidor single

//routes --- rutas del servidor

//iniciar el servidor
app.listen(app.get('port'), () => {
    console.log('servidor activo en puerto 3000');
});

